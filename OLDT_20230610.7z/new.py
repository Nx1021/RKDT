from torch.utils.tensorboard import SummaryWriter

class Trainer:
    def __init__(self, model, train_dataset, val_dataset, criterion, batch_size, num_epochs, learning_rate):
        self.model:OLDT = model
        self.train_dataset = train_dataset
        self.val_dataset = val_dataset
        self.batch_size = batch_size
        self.num_epochs = num_epochs
        self.learning_rate = learning_rate
        
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model.to(self.device)
        
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.learning_rate)
        self.criterion = criterion
        
        self.best_val_loss = float('inf')  # 初始化最佳验证损失为正无穷大

        current_time = datetime.datetime.now()
        self.start_timestamp = current_time.strftime("%Y%m%d%H%M%S")

        # 创建TensorBoard的SummaryWriter对象，指定保存日志文件的目录
        self.log_dir = "./logs/" + self.start_timestamp  # TensorBoard日志文件保存目录
        self.writer = SummaryWriter(log_dir=self.log_dir)  # 创建SummaryWriter对象

    def _to_device(self, tensor_list:list[torch.Tensor]):
        return [x.to(self.device) for x in tensor_list]

    def train_once(self, dataloader, epoch):
        self.model.train()
        ldmk_loss_mngr = LandmarkLossManager()

        progress = tqdm(dataloader, desc='Training', leave=True)
        for images, keypoints, labels, bboxes in progress:
            keypoints = self._to_device(keypoints)
            labels = self._to_device(labels)
            bboxes = self._to_device(bboxes)

            # 前向传播
            detection_results = self.model(images)
            loss, detect_num = self.criterion(keypoints, bboxes, detection_results)

            # 反向传播和优化
            if detect_num > 0:
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

                # 计算批次的准确率和损失
                ldmk_loss_mngr.update(loss.item() * detect_num, detect_num)

                # 更新进度条信息
                progress.set_postfix({'Loss': "{:>8.4f}".format(ldmk_loss_mngr.mean)})

        # 计算平均训练损失
        print('Train Mean Loss: {:>8.4f}'.format(ldmk_loss_mngr.mean))

        # 将train_loss写入TensorBoard日志文件
        self.writer.add_scalar("Train Loss", ldmk_loss_mngr.mean, epoch)

        return ldmk_loss_mngr.mean

    def val_once(self, dataloader, epoch):
        self.model.eval()
        ldmk_loss_mngr = LandmarkLossManager()

        progress = tqdm(dataloader, desc='Validation', leave=True)
        with torch.no_grad():
            for images, keypoints, labels, bboxes in progress:
                keypoints = self._to_device(keypoints)
                labels = self._to_device(labels)
                bboxes = self._to_device(bboxes)
                # 前向传播
                detection_results = self.model(images)
                loss, detect_num = self.criterion(keypoints, bboxes, detection_results)

                # 计算批次的损失
                if detect_num > 0:
                    ldmk_loss_mngr.update(loss.item() * detect_num, detect_num)
                    progress.set_postfix({'Loss': "{:>8.4f}".format(ldmk_loss_mngr.mean)})

        # 计算平均验证损失
        print('Val Mean Loss: {:>8.4f}'.format(ldmk_loss_mngr.mean))

        # 将val_loss写入TensorBoard日志文件
        self.writer.add_scalar("Val Loss", ldmk_loss_mngr.mean, epoch)

        return ldmk_loss_mngr.mean

    def train(self):
        print("start to train... time:{}".format(self.start_timestamp))
        train_dataloader = DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=True, collate_fn=collate_fn)
        val_dataloader = DataLoader(self.val_dataset, batch_size=self.batch_size, shuffle=False, collate_fn=collate_fn)
        
        # 用于保存每个epoch的train_loss和val_loss
        train_losses = []
        val_losses = []

        for epoch in range(self.num_epochs):
            tqdm.write('\nEpoch {} start...'.format(epoch + 1))
            # 训练阶段
            train_loss = self.train_once(train_dataloader, epoch)

            # 验证阶段
            val_loss = self.val_once(val_dataloader, epoch)

            # 如果验证损失低于历史最小值，则保存模型权重
            if val_loss < self.best_val_loss:
                print("new best val_loss: {}, saving...".format(val_loss))
                self.best_val_loss = val_loss
                self.model.save_branch_weights("./weights/", self.start_timestamp)

            # 更新进度条信息
            tqdm.write('Epoch {} - Train Loss: {:.4f} - Val Loss: {:.4f}'.format(epoch + 1, train_loss, val_loss))

            # 将train_loss和val_loss添加到列表中
            train_losses.append(train_loss)
            val_losses.append(val_loss)

        # 保存TensorBoard日志文件
        self.writer.flush()
        self.writer.close()

        return train_losses, val_losses
