from ultralytics.yolo.utils import ops, yaml_load

import torch
import torch.nn as nn
from torch import Tensor
from torchvision.ops.boxes import box_area
from torchvision.ops import generalized_box_iou
from scipy.optimize import linear_sum_assignment
from models.FeatureMapDistribute import LandmarkDetectionResult


class LandmarkLoss(nn.Module):
    def __init__(self, cfg) -> None:
        super().__init__()
        self.cfg = yaml_load(cfg)
        self.landmark_num:int = self.cfg["landmark_num"]

    def match(self, gt_bbox_n, rlts: list[LandmarkDetectionResult]):
        pred_bbox_n = torch.stack([x.bbox_n for x in rlts]) # [num_roi_active, 4]
        ### 用giou将预测的框和真值的框匹配
        cost_matrix         = generalized_box_iou(pred_bbox_n, gt_bbox_n)
        row_ind, col_ind    = linear_sum_assignment(cost_matrix.cpu(), maximize=True)
        return row_ind, col_ind

    def get_target(self, gt_landmarks, row_ind, col_ind, rlts:list[LandmarkDetectionResult]):
        pred_bbox           = torch.stack([x.bbox for x in rlts])   # [num_roi_active, 4]
        target_landmarks    = gt_landmarks[col_ind]   # [match_num, ldmk_num, 2]
        matched_pred_bbox   = pred_bbox[row_ind]      # [match_num, 4]
        matched_lt          = matched_pred_bbox[:, :2] # [match_num, (x, y)]
        matched_wh          = matched_pred_bbox[:, 2:] - matched_pred_bbox[:, :2] # [match_num, (w, h)]
        matched_lt          = matched_lt.unsqueeze(1).repeat(1, self.landmark_num, 1) # [match_num, ldmk_num, (w, h)]
        matched_wh          = matched_wh.unsqueeze(1).repeat(1, self.landmark_num, 1) # [match_num, ldmk_num, (w, h)]
        target_landmarks_n  = (target_landmarks - matched_lt) / matched_wh # [match_num, ldmk_num, (w, h)]
        return target_landmarks_n


    def forward(self, 
                gt_landmarks_list:list[Tensor], 
                gt_bboxes_n_list:list[Tensor], 
                pred_results_list:list[list[LandmarkDetectionResult]]):
        '''
        parameters
        -----
        '''
        BN = len(pred_results_list)
        distance = torch.Tensor([0.0]).to(gt_landmarks_list[0].device)
        group_matched_num = 0
        for bn in range(BN):
            rlts = pred_results_list[bn]
            if len(rlts) == 0:
                continue
            ### 将关键点真值（pixel）在预测的bboxes内归一化
            # with torch.no_grad():
            row_ind, col_ind = self.match(gt_bboxes_n_list[bn],  #[num_roi_gt, 4]
                                            rlts) 
            group_matched_num += len(row_ind)
            if len(row_ind) == 0:
                continue # 未能找到匹配的roi
            target_landmarks_n = self.get_target(gt_landmarks_list[bn], 
                                                    row_ind, col_ind, 
                                                    rlts)
            ### 计算距离
            pred_landmarks_n = torch.stack([x.landmarks_n for x in rlts], dim=1) # [output_num, num_roi_active, ldmk_num, 2]
            output_num = pred_landmarks_n.shape[0]
            target_landmarks_n = target_landmarks_n.unsqueeze(1).repeat(1, output_num, 1,1) # [match_num, output_num, ldmk_num, (w, h)]
            pred_landmarks_n = torch.transpose(pred_landmarks_n, 0, 1) # [num_roi_active, output_num, ldmk_num, 2]            
            matched_pred_landmarks_n = pred_landmarks_n[row_ind] # [match_num, ldmk_num, (w, h)]
            dist = torch.linalg.norm(matched_pred_landmarks_n - target_landmarks_n, dim = -1) # [match_num, output_num, ldmk_num]
            dist = torch.mean(dist, dim = (1,2))
            distance += torch.sum(dist)
        if group_matched_num > 0:
            distance = distance / group_matched_num
        return distance, group_matched_num

if __name__ == "__main__":
    A = torch.Tensor([[0, 0, 0.5, 0.5], [0.25, 0.25, 0.75, 0.75]])
    B = torch.Tensor([[0.25, 0.25, 0.75, 0.75], [0.5, 0.5, 1, 1]])
    r = generalized_box_iou(A, B)
    print()