import os
import torch
from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pad_sequence

import numpy as np
from models.OLDT import OLDT
from models.loss import LandmarkLoss
import os
import cv2
from tqdm import tqdm
import matplotlib.pyplot as plt
import datetime
import platform

sys = platform.system()
if sys == "Windows":
    TESTFLOW = True
else:
    TESTFLOW = False

def collate_fn(batch_data):
    """
    自定义 batch 内各个数据条目的组织方式
    :param data: 元组，第一个元素：句子序列数据，第二个元素：长度 第2维：句子标签
    :return: 填充后的句子列表、实际长度的列表、以及label列表
    """
    # padding_values = [0, 0, -1, 0]
    # images, keypoints, class_ids, bboxes = [pad_sequence([bd[i] for bd in batch_data], 
    #                                                      batch_first=True, 
    #                                                      padding_value = padding_values[i])
    #                                             for i in range(4)]
    images, keypoints, class_ids, bboxes = [[bd[i] for bd in batch_data]
                                                for i in range(4)]
    return images, keypoints, class_ids, bboxes

class LandmarkLossManager():
    def __init__(self) -> None:
        self.loss_sum = 0.0
        self.detect_num_sum = 0

    def update(self, loss, detect_num):
        self.loss_sum += loss
        self.detect_num_sum += detect_num

    def clear(self):
        self.loss_sum = 0.0
        self.detect_num_sum = 0

    @property
    def mean(self):
        if self.detect_num_sum > 0:
            return self.loss_sum / self.detect_num_sum
        else:
            return float('inf')

class CustomDataset(Dataset):
    def __init__(self, data_folder, set_):
        self.data_folder = data_folder
        self.set = set_
        self.image_folder = os.path.join(data_folder, 'images', set_)
        self.keypoints_folder = os.path.join(data_folder, 'keypoints', set_)
        self.labels_folder = os.path.join(data_folder, 'labels', set_)
        self.data_files = os.listdir(self.image_folder)

    def __len__(self):
        return len(self.data_files)
    
    @staticmethod
    def _box_cxcywh2xyxy(bbox):
        x1 = bbox[:, 0] - bbox[:, 2] / 2
        y1 = bbox[:, 1] - bbox[:, 3] / 2
        x2 = bbox[:, 0] + bbox[:, 2] / 2
        y2 = bbox[:, 1] + bbox[:, 3] / 2

        # 将 x1, y1, x2, y2 组合成新的包围框表示
        new_bbox = torch.stack([x1, y1, x2, y2], dim=1)
        return new_bbox

    def __getitem__(self, idx):
        file_name = self.data_files[idx]
        image_path = os.path.join(self.image_folder, file_name)
        keypoints_path = os.path.join(self.keypoints_folder, file_name.replace('.jpg', '.txt'))
        labels_path = os.path.join(self.labels_folder, file_name.replace('.jpg', '.txt'))
        
        # 读取图像数据
        # image = cv2.cvtColor(cv2.imread(image_path), cv2.COLOR_BGR2RGB)
        # image = torch.Tensor(image.transpose((2,0,1)))
        image = cv2.imread(image_path)
        
        # 读取关键点数据
        keypoints_data = torch.from_numpy(np.loadtxt(keypoints_path))
        keypoints = keypoints_data.reshape(-1, 24, 2)
        
        # 读取标签数据
        labels_data = torch.from_numpy(np.loadtxt(labels_path))
        labels_data = labels_data.reshape(-1, 5)
        class_id = labels_data[:, 0].long()  # class_id
        bbox = labels_data[:, 1:]  # bbox (cx, cy, w, h)
        bbox = self._box_cxcywh2xyxy(bbox) # bbox (x1, x2, w, h)
        
        return image, keypoints, class_id, bbox

class Trainer:
    def __init__(self, model, train_dataset, val_dataset, criterion, batch_size, num_epochs, learning_rate):
        self.model:OLDT = model
        self.train_dataset = train_dataset
        self.val_dataset = val_dataset
        self.batch_size = batch_size
        self.num_epochs = num_epochs
        self.learning_rate = learning_rate
        
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model.to(self.device)
        
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.learning_rate)
        self.criterion = criterion
        
        self.best_val_loss = float('inf')  # 初始化最佳验证损失为正无穷大

        current_time = datetime.datetime.now()
        self.start_timestamp = current_time.strftime("%Y%m%d%H%M%S")

        # 创建TensorBoard的SummaryWriter对象，指定保存日志文件的目录
        self.log_dir = "./logs/" + self.start_timestamp  # TensorBoard日志文件保存目录
        self.writer = SummaryWriter(log_dir=self.log_dir)  # 创建SummaryWriter对象

        self.cur_epoch = 0

    def _to_device(self, tensor_list:list[torch.Tensor]):
        return [x.to(self.device) for x in tensor_list]

    def train_once(self, dataloader):
        self.model.train()
        ldmk_loss_mngr = LandmarkLossManager()

        progress = tqdm(dataloader, desc='Training', leave=True)
        for images, keypoints, labels, bboxes in progress:
            keypoints = self._to_device(keypoints)
            labels = self._to_device(labels)
            bboxes = self._to_device(bboxes)

            # 前向传播
            detection_results = self.model(images)
            loss, detect_num = self.criterion(keypoints, bboxes, detection_results)

            # 反向传播和优化
            if detect_num > 0:
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

                # 计算批次的准确率和损失
                ldmk_loss_mngr.update(loss.item() * detect_num, detect_num)

                # 更新进度条信息
                progress.set_postfix({'Loss': "{:>8.4f}".format(ldmk_loss_mngr.mean)})
            if TESTFLOW:
                break

        # 计算平均训练损失
        print('Train Mean Loss: {:>8.4f}'.format(ldmk_loss_mngr.mean))

        # 将train_loss写入TensorBoard日志文件
        self.writer.add_scalar("Train Loss", ldmk_loss_mngr.mean, self.cur_epoch)

        return ldmk_loss_mngr.mean

    def val_once(self, dataloader):
        self.model.eval()
        ldmk_loss_mngr = LandmarkLossManager()

        progress = tqdm(dataloader, desc='Validation', leave=True)
        with torch.no_grad():
            for images, keypoints, labels, bboxes in progress:
                keypoints = self._to_device(keypoints)
                labels = self._to_device(labels)
                bboxes = self._to_device(bboxes)
                # 前向传播
                detection_results = self.model(images)
                loss, detect_num = self.criterion(keypoints, bboxes, detection_results)

                # 计算批次的损失
                if detect_num > 0:
                    ldmk_loss_mngr.update(loss.item() * detect_num, detect_num)
                    progress.set_postfix({'Loss': "{:>8.4f}".format(ldmk_loss_mngr.mean)})
                if TESTFLOW:
                    break
                
        # 计算平均验证损失
        print('Val Mean Loss: {:>8.4f}'.format(ldmk_loss_mngr.mean))

        # 将val_loss写入TensorBoard日志文件
        self.writer.add_scalar("Val Loss", ldmk_loss_mngr.mean, self.cur_epoch)

        return ldmk_loss_mngr.mean

    def train(self, val_only = False):
        print("start to train... time:{}".format(self.start_timestamp))
        self.cur_epoch = 0
        train_dataloader = DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=True, collate_fn=collate_fn)
        val_dataloader = DataLoader(self.val_dataset, batch_size=self.batch_size, shuffle=False, collate_fn=collate_fn)
        
        # 用于保存每个epoch的train_loss和val_loss
        train_losses = []
        val_losses = []

        for epoch in range(self.num_epochs):
            self.cur_epoch = epoch + 1
            tqdm.write('\nEpoch {} start...'.format(self.cur_epoch))
            # 训练阶段
            if not val_only:
                train_loss = self.train_once(train_dataloader)

            # 验证阶段
            val_loss = self.val_once(val_dataloader)

            # 如果验证损失低于历史最小值，则保存模型权重
            if val_loss < self.best_val_loss:
                print("new best val_loss: {}, saving...".format(val_loss))
                self.best_val_loss = val_loss
                self.model.save_branch_weights("./weights/", self.start_timestamp)

            # 更新进度条信息
            tqdm.write('Epoch {} - Train Loss: {:.4f} - Val Loss: {:.4f}'.format(self.cur_epoch, train_loss, val_loss))

            # 将train_loss和val_loss添加到列表中
            train_losses.append(train_loss)
            val_losses.append(val_loss)

        # 保存TensorBoard日志文件
        self.writer.flush()
        self.writer.close()

