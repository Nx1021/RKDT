from models.OLDT import OLDT
from ultralytics import YOLO, yolo
from ultralytics.yolo.v8.detect import DetectionPredictor
import numpy as np
import torch
import cv2
import time



if __name__ == "__main__":
    yolo_weight_path = "weights/best.pt"
    cfg = "cfg/train_yolo.yaml"
    ###
    oldt = OLDT(yolo_weight_path, cfg, [0, 2])
    img = cv2.cvtColor(cv2.imread("000005.jpg"), cv2.COLOR_BGR2RGB)
    oldt(img)
    # oldt(["000005.jpg", "001136.jpg", "008160.jpg"])
    ###


    # ###
    # libyolo = YOLO(yolo_weight_path, "detect")
    # # myyolo = MyDetectionModel("yolov8l.yaml", nc = 9)
    # rlt = libyolo.predict("000005.jpg")
    # print()
    # start = time.time()
    # for i in range(100):
    #     rlt = libyolo.predict("000005.jpg")
    # print(time.time() - start)
    ###