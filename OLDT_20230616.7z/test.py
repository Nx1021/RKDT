from ultralytics import YOLO
from ultralytics.nn.tasks import DetectionModel
import matplotlib.pyplot as plt
import torch
import cv2
import platform

from Trainer import Trainer, CustomDataset
from models.loss import LandmarkLoss
from models.OLDT import OLDT

from torchvision.ops import roi_align

torch.set_default_dtype(torch.float32)

if __name__ == '__main__':
    sys = platform.system()
    print(sys)
    # if sys == "Windows":
    #     print("OS is Windows!!!")
    #     yolo = YOLO("./weights/yolov8l.pt")
    #     # result = yolo.predict("test.jpg")
    #     yolo.train(cfg = "./cfg/train_yolo_win.yaml")
    #     # plt.imshow(result[0].plot())
    #     print()
    # elif sys == "Linux":
    #     print("OS is Linux!!!")
    #     yolo = YOLO("./weights/yolov8l.pt")
    #     # result = yolo.predict("test.jpg")
    #     yolo.train(cfg = "./cfg/default.yaml")
    #     # plt.imshow(result[0].plot())
    #     print()
    # else:
    #     pass

    # 示例用法
    data_folder = './datasets/morrison'
    yolo_weight_path = "weights/best.pt"
    cfg = "cfg/default.yaml"
    ###
    train_dataset = CustomDataset(data_folder, "train")
    val_dataset = CustomDataset(data_folder, "val")
    loss = LandmarkLoss(cfg)
    model = OLDT(yolo_weight_path, cfg, [0])  # 替换为你自己的模型
    model.load_branch_weights(0, "./weights/20230612025707branch00.pt")
    num_epochs = 10
    learning_rate = 0.0001

    if sys == "Windows":
        batch_size = 4
    elif sys == "Linux":
        batch_size = 32
    trainer = Trainer(model, train_dataset, val_dataset, loss, batch_size, num_epochs, learning_rate, test = False)
    trainer.train()

